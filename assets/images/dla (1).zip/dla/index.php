<?php include('header.php');?>
<section class="homepage-banner">
  <div class="hero-main-rp container">
    <div class="row">
      <div class="col-lg-7">
        <h2 class="clip-animate">A full stack<br/> digital agency<br/> focused on web.</h2>
        <p class="clip-animate">We are a creative team of designers, developers, marketing strategists, and producers building modern websites all over the world.</p>
     <div class="chat-btn clip-animate">
					 <a href="#" >Our Services<img src="<?php echo home ?>/assets/images/arrow.png"></a>
				</div> 
        <ul class="headr-icon clip-animate">
        	<li><img src="<?php echo home ?>/assets/images/clutch.svg"></li>
        	<li><img src="<?php echo home ?>/assets/images/yext.svg"></li>
        	<li><img src="<?php echo home ?>/assets/images/google-partner.svg"></li>
        </ul>
      </div>
    </div>
  </div>

  <div id="particle-image" data-params-src="assets/js/params.json"></div>
  <div id="wrapper"></div>
</section>
<section class="homepage-sectionone">
	<div class="hero-main-rp container">
		<div class="row">
			<div class="col-lg-10">
				<h2>Brands that Move</h2>
				<p class="p-left">Spearheading your brand’s digital transformation through thoughtful design ideas, a personalized customer experience, and employing innovative strategies focused on commerce success.<br/>
					<br/>
				For nearly 12 years, B2B and B2C companies from around the world have trusted Design Layer Agency to bring ideas to market in a competitive time.</p>
			</div>
			<div class="col-lg-2">
				<div class="learnmr-btn">
					 <a href="#">Learn More<img src="<?php echo home ?>/assets/images/arrow2.svg"></a>
				</div>
			</div>
		</div>
	</div>
	<div class="owl-row">
			<div class="owl-carousel owl-theme owl-case-study">
				<div class="item first-slide-casestudy" style="background:#0155AB;">
					<div class="case-study-box">
							<div class="row">
								<div class="col-md-5">
									<div class="logo-case">
										<a href="#"><img src="<?php echo home ?>/assets/images/furniture-caselogo.svg"></a>
									</div>
									<ul class="technology-case">
										<li>ui/ux</li>
										<li>development</li>
										<li>seo</li>
										<li>hosting</li>
									</ul>
									<h3>jig furniture</h3>
									<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,</p>
									<a href="#" class="btn-website">view website <img src="<?php echo home ?>/assets/images/whitearrow.svg"></a>
								</div>
								<div class="col-md-7">
									<img src="<?php echo home ?>/assets/images/furniture-case.svg">
								</div>
							</div>
						</div>
				</div>
				<div class="first-slide-casestudy" style="background:#0155AB;">
					<div class="case-study-box">
							<div class="row">
								<div class="col-md-5">
									<div class="logo-case">
										<a href="#"><img src="<?php echo home ?>/assets/images/furniture-caselogo.svg"></a>
									</div>
									<ul class="technology-case">
										<li>ui/ux</li>
										<li>development</li>
										<li>seo</li>
										<li>hosting</li>
									</ul>
									<h3>jig furniture</h3>
									<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,</p>
									<a href="#" class="btn-website">view website <img src="<?php echo home ?>/assets/images/whitearrow.svg"></a>
								</div>
								<div class="col-md-7">
									<img src="<?php echo home ?>/assets/images/furniture-case.svg">
								</div>
							</div>
						</div>
				</div>
				<div class="first-slide-casestudy" style="background:#0155AB;">
					<div class="case-study-box">
							<div class="row">
								<div class="col-md-5">
									<div class="logo-case">
										<a href="#"><img src="<?php echo home ?>/assets/images/furniture-caselogo.svg"></a>
									</div>
									<ul class="technology-case">
										<li>ui/ux</li>
										<li>development</li>
										<li>seo</li>
										<li>hosting</li>
									</ul>
									<h3>jig furniture</h3>
									<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,</p>
									<a href="#" class="btn-website">view website <img src="<?php echo home ?>/assets/images/whitearrow.svg"></a>
								</div>
								<div class="col-md-7">
									<img src="<?php echo home ?>/assets/images/furniture-case.svg">
								</div>
							</div>
						</div>
				</div>
					<div class="first-slide-casestudy" style="background:#0155AB;">
						<div class="case-study-box">
							<div class="row">
								<div class="col-md-5">
									<div class="logo-case">
										<a href="#"><img src="<?php echo home ?>/assets/images/furniture-caselogo.svg"></a>
									</div>
									<ul class="technology-case">
										<li>ui/ux</li>
										<li>development</li>
										<li>seo</li>
										<li>hosting</li>
									</ul>
									<h3>jig furniture</h3>
									<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,</p>
									<a href="#" class="btn-website">view website <img src="<?php echo home ?>/assets/images/whitearrow.svg"></a>
								</div>
								<div class="col-md-7">
									<img src="<?php echo home ?>/assets/images/furniture-case.svg">
								</div>
							</div>
						</div>
				</div>
			</div>
		</div>
</section>
<section class="homepage-sectionsecond">
	<div class="hero-main-rp container">
		<div class="row">
			<div class="col-lg-12">
				<h2>What we do</h2>
				<p class="p-center">Transforming business challenges into unforgettable web and mobile solutions..</p>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-6 gsap-fixed-sidebar" style="padding-top: 100px;">
					<canvas id="canvas" width="100%" height="500px" ></canvas>
			</div>
			<div class="col-lg-6 gsap-scrollable">
				<div class=" services-home">
					<div class="">
						<span>01</span>
						<h3>Branding & Designing</h3>
						<p>(Tap into DLA, if your brand is in need for a potent brand strategy, story, or visual style guide)<br/>
								<br/>
								(Crafting Custom high-end Web design, driven from smart brand-centric and results driven strategies is our specialty.)</p>
						<ul class="service-list-home">
							<li><a href="#">UI/UX Design</a></li>
							<li><a href="#">Brand & Visual Design</a></li>
							<li><a href="#">Marketing Collateral</a></li>
							<li><a href="#">Mobile App Design</a></li>
							<li><a href="#">Logo Design</a></li>
							<li><a href="#">Interaction Design</a></li>
						</ul>
						<ul class="service-technology">
							<li><a href="#"><img src="<?php echo home ?>/assets/images/xd-img.svg"></a></li>
							<li><a href="#"><img src="<?php echo home ?>/assets/images/diamond-img.svg"></a></li>
							<li><a href="#"><img src="<?php echo home ?>/assets/images/figma-img.svg"></a></li>
							<li><a href="#"><img src="<?php echo home ?>/assets/images/link-img.svg"></a></li>
							<li><a href="#"><img src="<?php echo home ?>/assets/images/ps-img.svg"></a></li>
						</ul>
					</div>
				</div>
				<div class=" services-home">
					<div class="">
						<span>02</span>
						<h3>Digital Marketing & Sales Optimization</h3>
						<p>(DLA’s Marketing Mixologists craft smart strategies for modern digital advertising, SEO, social media, and email marketing) 
							<br/>
							<br/>
							(Our conversion rate optimization and digital transformation strategies improve sales leads for numerous agencies & brands, engagements, and market share)</p>
						<ul class="service-list-home">
							<li><a href="#">Pay Per Click (PPC) Services</a></li>
							<li><a href="#">Social Media Marketing</a></li>
							<li><a href="#">Email Marketing</a></li>
							<li><a href="#">Search Engine Optimization (SEO)</a></li>
							<li><a href="#">E-commerce Marketing</a></li>
							<li><a href="#">SMS Marketing</a></li>
						</ul>
						<ul class="service-technology">
							<li><a href="#"><img src="<?php echo home ?>/assets/images/googledrive.svg"></a></li>
							<li><a href="#"><img src="<?php echo home ?>/assets/images/moz.svg"></a></li>
							<li><a href="#"><img src="<?php echo home ?>/assets/images/analytics.svg"></a></li>
							<li><a href="#"><img src="<?php echo home ?>/assets/images/emailchimp.svg"></a></li>
							<li><a href="#"><img src="<?php echo home ?>/assets/images/hubspot-s.svg"></a></li>
						</ul>
					</div>
				</div>
				<div class=" services-home">
					<div class="">
						<span>03</span>
						<h3>Web & Mobile App Development</h3>
						<p>(From Corporate website development, Ecommerce, custom Web & Mobile applications and product configurators our code is intelligent.)
							<br/>
							<br/>
						(We are a mobile app development company that specializes in both iOS & Android apps. We build sturdy apps with good user experience and performance with the help of our skilled app developers.)</p>
						<ul class="service-list-home">
							<li><a href="#">Web App Development</a></li>
							<li><a href="#">Web Development</a></li>
							<li><a href="#">MVP Development</a></li>
							<li><a href="#">Mobile Applications</a></li>
							<li><a href="#">E-commerce Solution</a></li>
							<li><a href="#">PWA Development</a></li>
						</ul>
						<ul class="service-technology">
							<li><a href="#"><img src="<?php echo home ?>/assets/images/shopify-s.svg"></a></li>
							<li><a href="#"><img src="<?php echo home ?>/assets/images/magento-s.svg"></a></li>
							<li><a href="#"><img src="<?php echo home ?>/assets/images/laravel-s.svg"></a></li>
							<li><a href="#"><img src="<?php echo home ?>/assets/images/wordpress-s.svg"></a></li>
							<li><a href="#"><img src="<?php echo home ?>/assets/images/js-s.svg"></a></li>
						</ul>
					</div>
				</div>
						
			</div>
		</div>
		<div class="readmore-sec-home">
			<h2>Let’s Increase Our Knowledge</h2>
			<div class="readmr-btn">
					 <a href="#">Read More <img src="<?php echo home ?>/assets/images/arrow.png"></a>
				</div>
		</div>
	</div>
</section>
<section class="homepage-sectionthree">
	<div class="hero-main-rp container">
		<h2>we partner with the best-in-class technology platforms</h2>
		<div class="row">
			<div class="col-lg-3">
				<div class="boxes-technology-home">
					<a href="#"><img src="<?php echo home ?>/assets/images/hubspot.svg"> </a>
				</div>
			</div>
			<div class="col-lg-3">
				<div class="boxes-technology-home">
					<a href="#"><img src="<?php echo home ?>/assets/images/adobe.svg"></a>
				</div>
			</div>
			<div class="col-lg-3">
				<div class="boxes-technology-home">
					<a href="#"><img src="<?php echo home ?>/assets/images/salesforce.svg"></a>
				</div>
			</div>
			<div class="col-lg-3">
				<div class="boxes-technology-home">
					<a href="#"><img src="<?php echo home ?>/assets/images/magento.svg"></a>
				</div>
			</div>
		</div>
		 <div class="row">
			<div class="col-lg-3">
				<div class="boxes-technology-home">
					<a href="#"><img src="<?php echo home ?>/assets/images/acquia.svg"></a>
				</div>
			</div>
			<div class="col-lg-3">
				<div class="boxes-technology-home">
					<a href="#"><img src="<?php echo home ?>/assets/images/shopify.svg"></a>
				</div>
			</div>
			<div class="col-lg-3">
				<div class="boxes-technology-home">
					<a href="#"><img src="<?php echo home ?>/assets/images/contentful.svg"></a>
				</div>
			</div>
			<div class="col-lg-3">
				<div class="boxes-technology-home">
					<a href="#"><img src="<?php echo home ?>/assets/images/klavivo.svg"></a>
				</div>
			</div>
		</div>
		 <div class="row">
			<div class="col-lg-3">
				<div class="boxes-technology-home">
					<a href="#"><img src="<?php echo home ?>/assets/images/drupal.svg"></a>
				</div>
			</div>
			<div class="col-lg-3">
				<div class="boxes-technology-home">
					<a href="#"><img src="<?php echo home ?>/assets/images/bigcommerce.svg"></a>
				</div>
			</div>
			<div class="col-lg-3">
				<div class="boxes-technology-home">
					<a href="#"><img src="<?php echo home ?>/assets/images/sap.svg"></a>
				</div>
			</div>
			<div class="col-lg-3">
				<div class="boxes-technology-home">
					<a href="#"><img src="<?php echo home ?>/assets/images/dynamics.svg"></a>
				</div>
			</div>
		</div>
	</div>
</section>
<section class="homepage-sectionfour">
	<div class="hero-main-rp container">
		<div class="row">
			<div class="col-lg-6">
				<h2>Website Support We Offer</h2>
				<p>Data & Analytics, UX Audits, Landing Page Design, Conversion Rate Optimization, A/B Testing, Multivariant Testing, Split Testing, Page Speed Optimization, Website Support, Monthly Reporting.</p>
				 <div class="chat-btn">
					 <a href="#" >let’s chat<img src="<?php echo home ?>/assets/images/arrow2.svg"></a>
				</div>
			</div>
			<div class="col-lg-6">
				<a href="#"><img src="<?php echo home ?>/assets/images/team.png"></a>
			</div>
		</div>
	</div>
</section>
<section class="homepage-sectionfive">
	<div class="hero-main-rp container">
		<h2>Featured Work</h2>
		<p>Take a look at some of our best website projects, our Design & Marketing experts have worked on.</p>
		<div class="row">
			<div class="col-lg-6">
				<div class="work-boxes-home" style="background: url('<?php echo home ?>/assets/images/workone.png');">
					<div class="inner-row">
						<div class="col-md-7">
							<a href="#"><img src="<?php echo home ?>/assets/images/worklogoone.svg"></a>
							<h3>THE FUTURE OF WORK</h3>
							<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
							<a href="#" class="btn-website">view website <img src="<?php echo home ?>/assets/images/whitearrow.svg"></a>
						</div>
						<div class="col-md-5">
							<a href="#"><img src="<?php echo home ?>/assets/images/maskone.png"></a>
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-6">
				<div class="work-boxes-home" style="background: url('<?php echo home ?>/assets/images/worktwo.png');">
					<div class="inner-row">
						<div class="col-md-7">
							<a href="#"><img src="<?php echo home ?>/assets/images/worklogotwo.svg"></a>
							<h3>unmatched performance in transportation</h3>
							<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
							<a href="#" class="btn-website">view website <img src="<?php echo home ?>/assets/images/whitearrow.svg"></a>
						</div>
						<div class="col-md-5">
							<a href="#"><img src="<?php echo home ?>/assets/images/maskone.png"></a>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-6">
				<div class="work-boxes-home" style="background: url('<?php echo home ?>/assets/images/workthree.png');">
					<div class="inner-row">
						<div class="col-md-7">
							<a href="#"><img src="<?php echo home ?>/assets/images/worklogothree.svg"></a>
							<h3>new & designed with purpose</h3>
							<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
							<a href="#" class="btn-website">view website <img src="<?php echo home ?>/assets/images/whitearrow.svg"></a>
						</div>
						<div class="col-md-5">
							<a href="#"><img src="<?php echo home ?>/assets/images/maskone.png"></a>
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-6">
				<div class="work-boxes-home" style="background: url('<?php echo home ?>/assets/images/workfour.png');">
					<div class="inner-row">
						<div class="col-md-7">
							<a href="#"><img src="<?php echo home ?>/assets/images/worklogofour.svg"></a>
							<h3>All your favourite cuisines in one place</h3>
							<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
							<a href="#" class="btn-website">view website <img src="<?php echo home ?>/assets/images/whitearrow.svg"></a>
						</div>
						<div class="col-md-5">
							<a href="#"><img src="<?php echo home ?>/assets/images/maskone.png"></a>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-6">
				<div class="work-boxes-home" style="background: url('<?php echo home ?>/assets/images/workfive.png');">
					<div class="inner-row">
						<div class="col-md-7">
							<a href="#"><img src="<?php echo home ?>/assets/images/worklogofive.svg"></a>
							<h3>DECORATE WITH PAPER WALL DECALS</h3>
							<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
							<a href="#" class="btn-website">view website <img src="<?php echo home ?>/assets/images/whitearrow.svg"></a>
						</div>
						<div class="col-md-5">
							<a href="#"><img src="<?php echo home ?>/assets/images/maskone.png"></a>
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-6">
				<div class="work-boxes-home" style="background: url('<?php echo home ?>/assets/images/worksix.png');">
					<div class="inner-row">
						<div class="col-md-7">
							<a href="#"><img src="<?php echo home ?>/assets/images/worklogosix.svg"></a>
							<h3>I re-teach people how to breathe</h3>
							<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
							<a href="#" class="btn-website">view website <img src="<?php echo home ?>/assets/images/whitearrow.svg"></a>
						</div>
						<div class="col-md-5">
							<a href="#"><img src="<?php echo home ?>/assets/images/maskone.png"></a>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="readmore-sec-home">
			<div class="readmr-btn">
					 <a href="#">Read More <img src="<?php echo home ?>/assets/images/arrow.png"></a>
				</div>
		</div>
	</div>
</section>
<section class="homepage-sectionsix">
	<div class="hero-main-rp container">
		<h2>Let’s go through our custom website design process</h2>
		<!-- Tabs navs -->
			<ul class="nav nav-tabs" id="myTab" role="tablist">
				<li class="nav-item active" role="presentation">
					<button class="nav-link active" id="one-tab" data-toggle="tab" data-target="#one" type="button" role="tab" aria-controls="one" aria-selected="true"><span>01</span><br/>Kick-Off & Discovery</button>
				</li>
				<li class="nav-item" role="presentation">
					<button class="nav-link" id="two-tab" data-toggle="tab" data-target="#two" type="button" role="tab" aria-controls="two" aria-selected="false"><span>02</span><br/>Digital Strategy</button>
				</li>
				<li class="nav-item" role="presentation">
					<button class="nav-link" id="three-tab" data-toggle="tab" data-target="#three" type="button" role="tab" aria-controls="three" aria-selected="false"><span>03</span><br/>Information Architecture</button>
				</li>
				<li class="nav-item" role="presentation">
					<button class="nav-link" id="four-tab" data-toggle="tab" data-target="#four" type="button" role="tab" aria-controls="four" aria-selected="false"><span>04</span><br/>Design Mockups</button>
				</li>
				<li class="nav-item" role="presentation">
					<button class="nav-link" id="five-tab" data-toggle="tab" data-target="#five" type="button" role="tab" aria-controls="five" aria-selected="false"><span>05</span><br/>Coding & Development</button>
				</li>
				<li class="nav-item" role="presentation">
					<button class="nav-link" id="six-tab" data-toggle="tab" data-target="#six" type="button" role="tab" aria-controls="six" aria-selected="false"><span>06</span><br/>Quality Assurance</button>
				</li>
				<li class="nav-item" role="presentation">
					<button class="nav-link" id="seven-tab" data-toggle="tab" data-target="#seven" type="button" role="tab" aria-controls="seven" aria-selected="false"><span>07</span><br/>Launch & Optimization</button>
				</li>
			</ul>
			<!-- Tabs navs -->
			<!-- Tabs content -->
			<div class="tab-content" id="myTabContent">
				<div class="tab-pane fade active in" id="one" role="tabpanel" aria-labelledby="one-tab">
					<div class="row">
						<div class="col-md-6">
							<img src="<?php echo home ?>/assets/images/kickoff-img.png">
						</div>
						<div class="col-md-6">
							<h3>Kick-Off & Discovery</h3>
							<p>Design Layer Agency hosts an initial meeting with the client to discuss the scope of the project, including platforms and channels, goals, target audience, existing brand strategies, and more.
							<br/>
							<br/>
							In this call, the digital strategist – who leads the project – will gather the necessary information to conduct in-depth competitor research and complete a comprehensive digital strategy.</p>
						</div>
					</div>
				</div>
				<div class="tab-pane fade" id="two" role="tabpanel" aria-labelledby="two-tab">
					 <div class="row">
						<div class="col-md-6">
							<img src="<?php echo home ?>/assets/images/kickoff-img.png">
						</div>
						<div class="col-md-6">
							<h3>Kick-Off & Discovery</h3>
							<p>Design Layer Agency hosts an initial meeting with the client to discuss the scope of the project, including platforms and channels, goals, target audience, existing brand strategies, and more.
							<br/>
							<br/>
							In this call, the digital strategist – who leads the project – will gather the necessary information to conduct in-depth competitor research and complete a comprehensive digital strategy.</p>
						</div>
					</div>
				</div>
				<div class="tab-pane fade" id="three" role="tabpanel" aria-labelledby="three-tab">
					 <div class="row">
						<div class="col-md-6">
							<img src="<?php echo home ?>/assets/images/kickoff-img.png">
						</div>
						<div class="col-md-6">
							<h3>Kick-Off & Discovery</h3>
							<p>Design Layer Agency hosts an initial meeting with the client to discuss the scope of the project, including platforms and channels, goals, target audience, existing brand strategies, and more.
							<br/>
							<br/>
							In this call, the digital strategist – who leads the project – will gather the necessary information to conduct in-depth competitor research and complete a comprehensive digital strategy.</p>
						</div>
					</div>
				</div>
				<div class="tab-pane fade" id="four" role="tabpanel" aria-labelledby="four-tab">
					 <div class="row">
						<div class="col-md-6">
							<img src="<?php echo home ?>/assets/images/kickoff-img.png">
						</div>
						<div class="col-md-6">
							<h3>Kick-Off & Discovery</h3>
							<p>Design Layer Agency hosts an initial meeting with the client to discuss the scope of the project, including platforms and channels, goals, target audience, existing brand strategies, and more.
							<br/>
							<br/>
							In this call, the digital strategist – who leads the project – will gather the necessary information to conduct in-depth competitor research and complete a comprehensive digital strategy.</p>
						</div>
					</div>
				</div>
				<div class="tab-pane fade" id="five" role="tabpanel" aria-labelledby="five-tab">
					 <div class="row">
						<div class="col-md-6">
							<img src="<?php echo home ?>/assets/images/kickoff-img.png">
						</div>
						<div class="col-md-6">
							<h3>Kick-Off & Discovery</h3>
							<p>Design Layer Agency hosts an initial meeting with the client to discuss the scope of the project, including platforms and channels, goals, target audience, existing brand strategies, and more.
							<br/>
							<br/>
							In this call, the digital strategist – who leads the project – will gather the necessary information to conduct in-depth competitor research and complete a comprehensive digital strategy.</p>
						</div>
					</div>
				</div>
				<div class="tab-pane fade" id="six" role="tabpanel" aria-labelledby="six-tab">
					 <div class="row">
						<div class="col-md-6">
							<img src="<?php echo home ?>/assets/images/kickoff-img.png">
						</div>
						<div class="col-md-6">
							<h3>Kick-Off & Discovery</h3>
							<p>Design Layer Agency hosts an initial meeting with the client to discuss the scope of the project, including platforms and channels, goals, target audience, existing brand strategies, and more.
							<br/>
							<br/>
							In this call, the digital strategist – who leads the project – will gather the necessary information to conduct in-depth competitor research and complete a comprehensive digital strategy.</p>
						</div>
					</div>
				</div>
				<div class="tab-pane fade" id="seven" role="tabpanel" aria-labelledby="seven-tab">
					 <div class="row">
						<div class="col-md-6">
							<img src="<?php echo home ?>/assets/images/kickoff-img.png">
						</div>
						<div class="col-md-6">
							<h3>Kick-Off & Discovery</h3>
							<p>Design Layer Agency hosts an initial meeting with the client to discuss the scope of the project, including platforms and channels, goals, target audience, existing brand strategies, and more.
							<br/>
							<br/>
							In this call, the digital strategist – who leads the project – will gather the necessary information to conduct in-depth competitor research and complete a comprehensive digital strategy.</p>
						</div>
					</div>
				</div>
			</div>
			<!-- Tabs content -->
	</div>
</section>
<section class="homepage-sectionseven">
	<div class="hero-main-rp container">
		<h2>Digital Global Trends</h2>
		<p class="p-center">Let’s discover the latest design ideas for business growth</p>
		<h4>Articles / Blogs</h4>
		<div class="row">
			<div class="col-md-4">
				<div class="blog-boxes-home">
					<a href=""><img src="<?php echo home ?>/assets/images/blog1.png"></a>
					<span class="date">july 21,2022</span>
					<h3><a href="#">10 Signs It’s Time to Finally Hire a Social Media Manager</a></h3>
				</div>
			</div>
			<div class="col-md-4">
				<div class="blog-boxes-home">
					<a href=""><img src="<?php echo home ?>/assets/images/blog2.png"></a>
					<span class="date">july 21,2022</span>
					<h3><a href="#">10 Signs It’s Time to Finally Hire a Social Media Manager</a></h3>
				</div>
			</div>
			<div class="col-md-4">
				<div class="blog-boxes-home">
					<a href=""><img src="<?php echo home ?>/assets/images/blog3.png"></a>
					<span class="date">july 21,2022</span>
					<h3><a href="#">10 Signs It’s Time to Finally Hire a Social Media Manager</a></h3>
				</div>
			</div>
		</div>
		<div class="readmore-sec-home">
			<div class="readmr-btn">
					 <a href="#">view more blogs <img src="<?php echo home ?>/assets/images/arrow.png"></a>
				</div>
		</div>
	</div>
</section>
<section class="homepage-sectionone discuss-section" style="background: url('<?php echo home ?>/assets/images/discuss.png');">
	<div class="hero-main-rp container">
		<div class="row">
			<div class="col-lg-10">
				<h2>Ready to discuss your ideas?</h2>
			</div>
			<div class="col-lg-2">
				<div class="learnmr-btn">
					 <a href="#">let’s chat<img src="<?php echo home ?>/assets/images/arrow2.svg"></a>
				</div>
			</div>
		</div>
	</div>
</section>
<section class="homepage-testimonials">
	<div class="hero-main-rp container">
		<h2>We thrive on <br/>client satisfaction</h2>
		<div class="testimonials">
			<div class="owl-carousel owl-theme owl-testimonials">
		    <div class="testimonials-box">
		    	<div class="row">
		    		<img src="<?php echo home ?>/assets/images/quote-right.svg" class="quote-right">
		    		<p class="testi-txt">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
		    		<div class="col-md-6">
		    			<div class="person-info">
		    				<div class="img-testi">
		    					<img src="<?php echo home ?>/assets/images/owais.png">
		    				</div>
		    				<div class="details-testi">
		    					<h3>owais khan sanjrani</h3>
		    					<p>lead of osama</p>
		    				</div>
		    			</div>
		    		</div>
		    		<div class="col-md-6">
		    			<p> 01 / 05 </p>

		    		</div>
		    	</div>
		    </div>
		    <div class="testimonials-box">
		    	<div class="row">
		    		<img src="<?php echo home ?>/assets/images/quote-right.svg" class="quote-right">
		    		<p class="testi-txt">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
		    		<div class="col-md-6">
		    			<div class="person-info">
		    				<div class="img-testi">
		    					<img src="<?php echo home ?>/assets/images/owais.png">
		    				</div>
		    				<div class="details-testi">
		    					<h3>owais khan sanjrani</h3>
		    					<p>lead of osama</p>
		    				</div>
		    			</div>
		    		</div>
		    		<div class="col-md-6">
		    			<p> 02 / 05 </p>

		    		</div>
		    	</div>
		    </div>
		    <div class="testimonials-box">
		    	<div class="row">
		    		<img src="<?php echo home ?>/assets/images/quote-right.svg" class="quote-right">
		    		<p class="testi-txt">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
		    		<div class="col-md-6">
		    			<div class="person-info">
		    				<div class="img-testi">
		    					<img src="<?php echo home ?>/assets/images/owais.png">
		    				</div>
		    				<div class="details-testi">
		    					<h3>owais khan sanjrani</h3>
		    					<p>lead of osama</p>
		    				</div>
		    			</div>
		    		</div>
		    		<div class="col-md-6">
		    			<p> 03 / 05 </p>

		    		</div>
		    	</div>
		    </div>
		    <div class="testimonials-box">
		    	<div class="row">
		    		<img src="<?php echo home ?>/assets/images/quote-right.svg" class="quote-right">
		    		<p class="testi-txt">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
		    		<div class="col-md-6">
		    			<div class="person-info">
		    				<div class="img-testi">
		    					<img src="<?php echo home ?>/assets/images/owais.png">
		    				</div>
		    				<div class="details-testi">
		    					<h3>owais khan sanjrani</h3>
		    					<p>lead of osama</p>
		    				</div>
		    			</div>
		    		</div>
		    		<div class="col-md-6">
		    			<p> 04 / 05 </p>

		    		</div>
		    	</div>
		    </div>
		    <div class="testimonials-box">
		    	<div class="row">
		    		<img src="<?php echo home ?>/assets/images/quote-right.svg" class="quote-right">
		    		<p class="testi-txt">Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
		    		<div class="col-md-6">
		    			<div class="person-info">
		    				<div class="img-testi">
		    					<img src="<?php echo home ?>/assets/images/owais.png">
		    				</div>
		    				<div class="details-testi">
		    					<h3>owais khan sanjrani</h3>
		    					<p>lead of osama</p>
		    				</div>
		    			</div>
		    		</div>
		    		<div class="col-md-6">
		    			<p> 04 / 05 </p>

		    		</div>
		    	</div>
		    </div>
			</div>
		</div>
	</div>
</section>
<!--Start Footer-->
<!--End Footer-->
<script type="text/javascript" src="https://unpkg.co/gsap@3/dist/gsap.min.js"></script>
<script type="text/javascript" src="https://unpkg.com/gsap@3/dist/ScrollTrigger.min.js"></script>
<script type="text/javascript" src="assets/js/particle-image.js"></script>
<script type="text/javascript">
	ScrollTrigger.create({  
	trigger: '.gsap-fixed-sidebar',
	pin: '.gsap-fixed-sidebar',
	start: 'top top',
	endtrigger: '.readmore-sec-home',
	end: 'bottom top-=' + window.innerHeight, 
	end: () => 'bottom top-=' + window.innerHeight, 
	})
	
	var seriveces = gsap.utils.toArray('.services-home')

	seriveces.forEach((srvice, i) => {

	  var srviceFade = gsap.fromTo(srvice, { autoAlpha: 0 }, { duration: 0.1, autoAlpha: 1 }, 0)

	  ScrollTrigger.create({  
	    trigger: srvice,
	    start: 'top center',
	    end: 'bottom center',
	    animation: srviceFade,
	    scrub: true,
	  })  
	  
	});
	var tabsInterval = setInterval(function () {	
		if($('.homepage-sectionsix ul#myTab li.active').next('li').length > 0){
			$('.homepage-sectionsix ul#myTab li.active').next('li').find('button').click();
		}
		else{			
			$('.homepage-sectionsix ul#myTab li:first-child button').click();
		}
	}, 5000);


</script>
	<script type="text/javascript">
		
                const sparkles = new Sparkles({
                  imagesArray: [
                    "assets/images/React.svg",
                    "assets/images/Vue.svg",
                    "assets/images/Angular.svg",
                    "assets/images/PHP.svg",
                    "assets/images/Laravel.svg",
                    "assets/images/Symfony.svg",
                    "assets/images/Nest.svg",
                    "assets/images/Node.svg",
                    "assets/images/Swift.svg",
                    "assets/images/Mariadb.svg",
                    "assets/images/Postgre.svg",
                    "assets/images/AWS.svg",
                    "assets/images/Azure.svg",
                    "assets/images/Docker.svg",
                    "assets/images/Sketch.svg",
                    "assets/images/Figma.svg",
                    "assets/images/XD.svg",
                    "assets/images/PS.svg",
                    "assets/images/AI.svg",
                  ],
                  canvasId: 'canvas',
                  numLines: 40000,
                  fieldOfView: 15,
                  color: '#4dd0e1',
                  timeout: 2500,
                  targetCoefficient: 0.010,
                  compressionSpeed: 2.8,
                });
                sparkles.init();


	</script>
	<?php include('footer.php');?>