<!--Start Header-->
<?php include('header.php');?>
<!--End Header-->

<section class="inner-banner" style="background: url('<?php echo home ?>/assets/images/about-banner.png');">
  <div class="hero-main-rp container">
    <div class="row">
   		<div class="col-md-12">
   			<h2>I Need To Talk To An <br/>Expert.</h2>
   		</div>
    </div>
  </div>
</section>
<section class="about-section-eight">
  <div class="hero-main-rp container">
  	<div class="row cntct-detail">
  		<div class="col-md-4">
  			<div class="cntct-box">
  				<p>Is your need urgent? <br/>If so, call our receptionist at</p>
  				<h3><a href="tel:2143216549" class="numbr">(214) 321-6549</a></h3>
  			</div>
  		</div>
  		<div class="col-md-4">
  			<div class="cntct-box">
  				<p><strong>Note: </strong>If you are a vendor with a product or service for us, please</p>
  				<h3><a href="#" class="clck-here">Click Here</a></h3>
  			</div>
  		</div>
  		<div class="col-md-4">
  			<div class="cntct-box">
  				<p>Looking for a Free Quote?<br/>We are here to serve you</p>
  				<h3><a href="#" class="quote">Get a Quote</a></h3>
  			</div>
  		</div>
  	</div>
  	<div class="form-block">
  		<form>
  			<div class="row">
  				<div class="col-md-6">
  					<label>full name*</label><br/>
  					<input type="text" name="name" placeholder="Your Name" id="name" required>
  				</div>
  				<div class="col-md-6">
  					<label>Company</label><br/>
  					<input type="text" name="company" placeholder="Your Company" id="company">
  				</div>
  			</div>
  			<div class="row">
  				<div class="col-md-6">
  					<label>Email Address*</label><br/>
  					<input type="email" name="email" placeholder="Your Email" id="email" required>
  				</div>
  				<div class="col-md-6">
  					<label>Phone</label><br/>
  					<input type="phone" name="phone" placeholder="Your Phone" id="phone" required>
  				</div>
  			</div>
  			<div class="row">
  				<div class="col-md-12">
  					<label>How can we help you?</label><br/>
  					<textarea id="textarea_abt" name="textarea_abt" placeholder="tell us about your product and your nearest plans on the design engagement"></textarea>
  				</div>
  			</div>
  			<div class="row">
  				<div class="col-md-12">
  					<label>How did you hear about us?</label><br/>
  					<select name="hear_us" id="hear_us" required>
						<option value="">How did you hear about us?</option>
						<option value="graphic">Google</option>
						<option value="web-Development">Social Media</option>
						<option value="app-development">News</option>
						<option value="devops">Friends</option>
						<option value="digital-marketing">Other</option>
					</select>
  				</div>
  			</div>
  			<div class="row">
  				<div class="col-md-12">
  					<p>I need to sign the NDA first</p>
  					<button type="submit" value="submit" name="submit_mailer" id="form-submit" class="btn lnk btn-main bg-btn">let’s talk <span><img src="<?php echo home ?>assets/images/submit.svg"><span></button>
  				</div>
  			</div>
  		</form>
  	</div>
  </div>
</section>
<section class="form-banner" style="background: url('<?php echo home ?>/assets/images/contact-bnner.png');">
	<div class="hero-main-rp container">
		<div class="row">
			<div class="col-lg-12">
				<h2><img src="<?php echo home ?>assets/images/heading-img.svg"><br/>Don’t Like Forms?</h2>
				<p><a href="#">click here</a> to speak to one of our solutions specialist</p>
			</div>
		</div>
	</div>
</section>
<section class="find-us-section">
	<div class="hero-main-rp container">
		<h2><img src="<?php echo home ?>assets/images/heading-img.svg"><br/>Where To Find Us</h2>
		<div class="row">
			<div class="col-lg-6">
				<div class="findus-box">
					<h3>Headquarters</h3>
					<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
					<h4><a href="#">show on map</a></h4>
					<img src="<?php echo home ?>assets/images/findus1.png" class="carer-img">
				</div>
			</div>
			<div class="col-lg-6">
				<div class="findus-box">
					<h3>work Center</h3>
					<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
					<h4><a href="#">show on map</a></h4>
					<img src="<?php echo home ?>assets/images/findus2.png" class="carer-img">
				</div>
			</div>
		</div>
	</div>
</section>
<section class="homepage-sectionone discuss-section" style="background: url('<?php echo home ?>/assets/images/discuss.png');">
	<div class="hero-main-rp container">
		<div class="row">
			<div class="col-lg-10">
				<h2>Ready to discuss your ideas?</h2>
			</div>
			<div class="col-lg-2">
				<div class="learnmr-btn">
					 <a href="#">let’s chat<img src="<?php echo home ?>/assets/images/arrow2.svg"></a>
				</div>
			</div>
		</div>
	</div>
</section>
<!--Start Footer-->
	<?php include('footer.php');?>
<!--End Footer-->