<footer class="main-footer">

	<div class="footer-row1">

		<div class="container">
			<h2>Awards And Acknowledgements</h2>
			<div class="row">
				<div class="col-lg-2">
					<a href="#"><img src="http://localhost/dla/assets/images/f-logos4.png"></a>
				</div>

				<div class="col-lg-2">
					<a href="#"><img src="http://localhost/dla/assets/images/f-logos3.png"></a>
				</div>
				<div class="col-lg-2">
					<a href="#"><img src="http://localhost/dla/assets/images/f-logos2.png"></a>
				</div>
				<div class="col-lg-2">
					<a href="#"><img src="http://localhost/dla/assets/images/f-logos1.png"></a>
				</div>
				<div class="col-lg-2">
					<a href="#"><img src="http://localhost/dla/assets/images/f-logos.png"></a>
				</div>

			</div>

		</div>

	</div>

	<div class="footer-row2">

		<div class="container">

			<div class="row">
				<div class="col-lg-3">
					<a href="#"><img src="http://localhost/dla/assets/images/logo.svg"></a>
					<ul class="social-footer">
						<li><a href="#"><img src="http://localhost/dla/assets/images/facebook.svg"></a></li>
						<li><a href="#"><img src="http://localhost/dla/assets/images/twitter.svg"></a></li>
						<li><a href="#"><img src="http://localhost/dla/assets/images/linkdin.svg"></a></li>
						<li><a href="#"><img src="http://localhost/dla/assets/images/instagram.svg"></a></li>
					</ul>
					<div class="reviews-footer">
						<div class="row">
							<div class="col-md-6">
								<h4>REVIEWED ON</h4>
								<a href="#"><img src="http://localhost/dla/assets/images/clutch-f.svg"></a>
							</div>
							<div class="col-md-6">
								<a href="#"><img src="http://localhost/dla/assets/images/review-f.svg"></a>
								<h4>40 Reviews</h4>
								
							</div>

						</div>
						<h5><a href="#">View All Testimonials</a></h5>
					</div>
				</div>
				<div class="col-lg-3">
					<h3>services</h3>
					<ul class="footer-links">
						<li><a href="#">Design Services</a></li>
						<li><a href="#">Digital Marketing</a></li>
						<li><a href="#">Software Development</a></li>
						<li><a href="#">Web Development Agency</a></li>
						<li><a href="#">Mobile App Development</a></li>
					</ul>
				</div>
				<div class="col-lg-3">
					<h3>quick links</h3>
					<ul class="footer-links">
						<li><a href="#">home </a></li>
						<li><a href="#">Work </a></li>
						<li><a href="#">Services</a></li>
						<li><a href="#">About</a></li>
						<li><a href="#">Insights</a></li>
						<li><a href="#">Digital Trends</a></li>
						<li><a href="#">Contact</a></li>
					</ul> 	
				</div>
				<div class="col-lg-3">
					<h3><img src="http://localhost/dla/assets/images/usa-flag.png">Delivery Center</h3>
					<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
					<a href="#" class="cntct-footer">(214) 321-6549</a>
					<a href="#" class="cntct-footer">info@designlayeragency.com</a>
					<h3><img src="http://localhost/dla/assets/images/pak-flag.png">Headquarters</h3>
					<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
					<a href="#" class="cntct-footer">(214) 321-6549</a>
					<a href="#" class="cntct-footer">info@designlayeragency.com</a>
				</div>

			</div>

		</div>

	</div>
	<div class="footer-siteinfo">
		<div class="container">
			<div class="row">
				<div class="col-md-6">
					<p>Copyright © 2022. <a href="#">design layer agency LLC</a>.</p>
				</div>
				<div class="col-md-6">
					<p><a href="#">Privacy Policy</a>. <a href="#">Terms and Conditions</a></p>
				</div>
			</div>
		</div>
	</div>
</footer>
<script type="text/javascript">
	


	$(document).ready(function() {
	 $('.owl-case-study').owlCarousel({
        loop: true,
        items:1,
        stagePadding: 130,
        center: true,
        margin: 60,
        dots:false,
        autoplay:true,
        responsiveClass: true,

        responsive: {
            0: {
               items: 1,
                nav: true
            },
            600: {
                items: 1,
                nav: false
            },
            1000: {
                items: 1,
            }
        }
    	});
	 $('.owl-testimonials').owlCarousel({
        loop: true,
        items:1,
        center:true,
        margin:30,
        autoplay:true,
        navText: ["<img src='<?php echo home ?>/assets/images/right-arrow.svg'>","<img src='<?php echo home ?>/assets/images/left-arrow.svg'>"],
        nav:true,
        // stagePadding: 150,
        dots:false,
        responsiveClass: true,

        responsive: {
            0: {
               items: 1,
                nav: true
            },
            600: {
                items: 1,
                nav: false
            },
            1000: {
                items: 1,
            }
        }
    	});
	 $('.owl-industries').owlCarousel({
        loop: true,
        items:1,
        margin:30,
        // autoplay:true,
        navText: ["<img src='<?php echo home ?>/assets/images/left-arrow-abt.svg'>","<img src='<?php echo home ?>/assets/images/right-arrow-abt.svg'>"],
        nav:true,
        // stagePadding: 150,
        dots:false,
        responsiveClass: true,

        responsive: {
            0: {
               items: 1,
            },
            600: {
                items: 2,
            },
            1000: {
                items: 4,
            }
        }
    	});
	 });
	jQuery(document).on('click', '.service-tabs-section .nav li a', function (event) {
		event.preventDefault();

		jQuery('html, body').animate({
			scrollTop: jQuery(jQuery.attr(this, 'href')).offset().top
		}, 1400);
	});
	$(document).ready(function() {
    $(".service-tabs-section .nav li").click(function () {
        if(!$(this).hasClass('active'))
        {
            $(".service-tabs-section .nav li").removeClass("active");
            $(this).addClass("active");        
        }
    });
});

</script>
</body></html>
