

<meta name="viewport" content="width=device-width,initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="ahrefs-site-verification" content="fd09c2ce37551b14778113709f6bf37f475c97a93cf0ac4b0da317037d111fe4">
<!--website-favicon-->
	<link rel="icon" href="http://localhost/dla/assets/images/favicon.png">
	<link rel="canonical" href="http://localhost/dla/" />
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.1.1/css/fontawesome.min.css" integrity="sha384-zIaWifL2YFF1qaDiAo0JFgsmasocJ/rqu7LKYH8CoBEXqGbb9eO+Xi3s6fQhgFWM" crossorigin="anonymous">
	
	<meta http-equiv="Cache-control" content="public">
	<!--plugin-css-->
	<link href="css/fontawesome.min.css" rel="stylesheet">
	<!-- <link rel="stylesheet" href="css/bootstrap.min.css"> -->
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.1.1/css/fontawesome.min.css" integrity="sha384-zIaWifL2YFF1qaDiAo0JFgsmasocJ/rqu7LKYH8CoBEXqGbb9eO+Xi3s6fQhgFWM" crossorigin="anonymous">
	<?php 
		$curent_uri = $_SERVER['REQUEST_URI'];
		if ($curent_uri == '/') { ?>
			<link href="http://localhost/dla/assets/css/header.css" rel="stylesheet">
	<?php }else { ?>
			<link href="http://localhost/dla/assets/css/style.css" rel="stylesheet">
	<?php } ?>
	
	<link href="css/responsive.css" rel="stylesheet">
	<script type="text/javascript" src="http://localhost/dla/assets/js/sparkles.js"></script>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="http://localhost/dla/assets/css/owl.carousel.min.css">
	<link rel="stylesheet" href="http://localhost/dla/assets/css/owl.theme.default.min.css">
	<script src="http://localhost/dla/assets/js/owl.carousel.min.js"></script>

