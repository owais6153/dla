<?php  
define('home', 'http://localhost/dla/');
?>