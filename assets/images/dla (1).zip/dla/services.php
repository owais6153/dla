<!--Start Header-->
<?php include('header.php');?>
<!--End Header-->

<section class="inner-banner service-banner" style="background: url('<?php echo home ?>/assets/images/about-banner.png');">
  <div class="hero-main-rp container">
    <div class="row">
   		<div class="col-md-12">
   			<h2><img src="<?php echo home ?>/assets/images/medal.svg" class="medal-img"> <br/>Digital Agency Services</h2>
   			<p>Experience the Texas-sized value of Agency Partner’s industry renowned custom software and internet marketing experts. Our digital agency has worked on over 1500 successful digital projects for more than 500 businesses.</p>
   			<div class="readmr-btn">
				<a href="#">what we offer <img src="<?php echo home ?>/assets/images/arrow.png"></a>
			</div>
   		</div>
    </div>
  </div>
</section>
<section class="service-tabs-section">
	<div class="hero-main-rp container">
			<ul class="nav">
				<li class="nav-item" role="presentation">
					<a href="#brand">brand Management & designing</a>
				</li>
				<li class="nav-item" role="presentation">
					<a href="#digital">Digital Marketing & Sales Optimization</a>
				</li>
				<li class="nav-item" role="presentation">
					<a href="#web">Web & Mobile App Development</a>
				</li>
			</ul>
			<div class="content-services">
				<div class="services-tab-details" id="brand">
					<div class="row">
						<div class="col-md-6">
							<h3><img src="<?php echo home ?>/assets/images/icon-heading.svg"><br/>Branding & Designing</h3>
							<p>(Tap into DLA, if your brand is in need for a potent brand strategy, story, or visual style guide) 
							<br/>
							<br/>
							(Crafting Custom high-end Web design, driven from smart brand-centric and results driven strategies is our specialty.)</p>
							<ul class="service-list-home">
								<li><a href="#">UI/UX Design</a></li>
								<li><a href="#">Brand & Visual Design</a></li>
								<li><a href="#">Marketing Collateral</a></li>
								<li><a href="#">Mobile App Design</a></li>
								<li><a href="#">Logo Design</a></li>
								<li><a href="#">Interaction Design</a></li>
							</ul>
							<ul class="service-technology">
								<li><a href="#"><img src="<?php echo home ?>/assets/images/xd-s.svg"></a></li>
								<li><a href="#"><img src="<?php echo home ?>/assets/images/diamond-s.svg"></a></li>
								<li><a href="#"><img src="<?php echo home ?>/assets/images/figma-s.svg"></a></li>
								<li><a href="#"><img src="<?php echo home ?>/assets/images/in-s.svg"></a></li>
								<li><a href="#"><img src="<?php echo home ?>/assets/images/ps-s.svg"></a></li>
							</ul>
							<div class="btn-services">
								<div class="btn-one">
									<a href="#">get in touch <img src="<?php echo home ?>/assets/images/arrow-blue.svg"></a>
								</div>
								<div class="btn-two">
									<a href="">learn more <img src="<?php echo home ?>/assets/images/arrow2.svg"></a>
								</div>
							</div>
						</div>
						<div class="col-md-6">
							<img src="<?php echo home ?>/assets/images/brand.png" class="image-service">
						</div>
					</div>
				</div>
				<div class="services-tab-details" id="digital">
					<div class="row">
						<div class="col-md-6">
							<h3><img src="<?php echo home ?>/assets/images/icon-heading.svg"><br/>Digital Marketing & Sales Optimization </h3>
							<p>(DLA’s Marketing Mixologists craft smart strategies for modern digital advertising, SEO, social media, and email marketing) 
								<br/>
								<br/>
							(Our conversion rate optimization and digital transformation strategies improve sales leads for numerous agencies & brands, engagements, and market share)</p>
							<ul class="service-list-home">
								<li><a href="#">Pay Per Click (PPC) Services</a></li>
								<li><a href="#">Social Media Marketing</a></li>
								<li><a href="#">Email Marketing</a></li>
								<li><a href="#">Search Engine Optimization (SEO)</a></li>
								<li><a href="#">E-commerce Marketing</a></li>
								<li><a href="#">SMS Marketing</a></li>
							</ul>
							<ul class="service-technology">
								<li><a href="#"><img src="<?php echo home ?>/assets/images/googledrive-s.svg"></a></li>
								<li><a href="#"><img src="<?php echo home ?>/assets/images/moz-s.svg"></a></li>
								<li><a href="#"><img src="<?php echo home ?>/assets/images/analytics-s.svg"></a></li>
								<li><a href="#"><img src="<?php echo home ?>/assets/images/mailer-s.svg"></a></li>
								<li><a href="#"><img src="<?php echo home ?>/assets/images/hubspot-ss.svg"></a></li>
							</ul>
							<div class="btn-services">
								<div class="btn-one">
									<a href="#">get in touch <img src="<?php echo home ?>/assets/images/arrow-blue.svg"></a>
								</div>
								<div class="btn-two">
									<a href="">learn more <img src="<?php echo home ?>/assets/images/arrow2.svg"></a>
								</div>
							</div>
						</div>
						<div class="col-md-6">
							<img src="<?php echo home ?>/assets/images/digital.png" class="image-service">
						</div>
					</div>
				</div>
				<div class="services-tab-details" id="web">
					<div class="row">
						<div class="col-md-6">
							<h3><img src="<?php echo home ?>/assets/images/icon-heading.svg"><br/>Web & Mobile App Development</h3>
							<p>(From Corporate website development, Ecommerce, custom Web & Mobile applications and product configurators our code is intelligent.)
							<br/>
							<br/>
 							(We are a mobile app development company that specializes in both iOS & Android apps. We build sturdy apps with good user experience and performance with the help of our skilled app developers.)</p>
							<ul class="service-list-home">
								<li><a href="#">Web App Development</a></li>
								<li><a href="#">Web Development</a></li>
								<li><a href="#">MVP Development</a></li>
								<li><a href="#">Mobile Applications</a></li>
								<li><a href="#">E-commerce Solution</a></li>
								<li><a href="#">PWA Development</a></li>
							</ul>
							<ul class="service-technology">
								<li><a href="#"><img src="<?php echo home ?>/assets/images/shopify-ss.svg"></a></li>
								<li><a href="#"><img src="<?php echo home ?>/assets/images/magento-ss.svg"></a></li>
								<li><a href="#"><img src="<?php echo home ?>/assets/images/laravel-ss.svg"></a></li>
								<li><a href="#"><img src="<?php echo home ?>/assets/images/wordpress-ss.svg"></a></li>
								<li><a href="#"><img src="<?php echo home ?>/assets/images/js-ss.svg"></a></li>
							</ul>
							<div class="btn-services">
								<div class="btn-one">
									<a href="#">get in touch <img src="<?php echo home ?>/assets/images/arrow-blue.svg"></a>
								</div>
								<div class="btn-two">
									<a href="">learn more <img src="<?php echo home ?>/assets/images/arrow2.svg"></a>
								</div>
							</div>
						</div>
						<div class="col-md-6">
							<img src="<?php echo home ?>/assets/images/web.png" class="image-service">
						</div>
					</div>
				</div>
			</div>
	</div>
</section>

<section class="homepage-testimonials">
	<div class="hero-main-rp container">
		<h2>We thrive on <br/>client satisfaction</h2>
		<div class="testimonials">
			<div class="owl-carousel owl-theme owl-testimonials">
		    <div class="testimonials-box">
		    	<div class="row">
		    		<img src="<?php echo home ?>/assets/images/quote-right.svg" class="quote-right">
		    		<p class="testi-txt">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
		    		<div class="col-md-6">
		    			<div class="person-info">
		    				<div class="img-testi">
		    					<img src="<?php echo home ?>/assets/images/owais.png">
		    				</div>
		    				<div class="details-testi">
		    					<h3>owais khan sanjrani</h3>
		    					<p>lead of osama</p>
		    				</div>
		    			</div>
		    		</div>
		    		<div class="col-md-6">
		    			<p> 01 / 05 </p>

		    		</div>
		    	</div>
		    </div>
		    <div class="testimonials-box">
		    	<div class="row">
		    		<img src="<?php echo home ?>/assets/images/quote-right.svg" class="quote-right">
		    		<p class="testi-txt">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
		    		<div class="col-md-6">
		    			<div class="person-info">
		    				<div class="img-testi">
		    					<img src="<?php echo home ?>/assets/images/owais.png">
		    				</div>
		    				<div class="details-testi">
		    					<h3>owais khan sanjrani</h3>
		    					<p>lead of osama</p>
		    				</div>
		    			</div>
		    		</div>
		    		<div class="col-md-6">
		    			<p> 02 / 05 </p>

		    		</div>
		    	</div>
		    </div>
		    <div class="testimonials-box">
		    	<div class="row">
		    		<img src="<?php echo home ?>/assets/images/quote-right.svg" class="quote-right">
		    		<p class="testi-txt">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
		    		<div class="col-md-6">
		    			<div class="person-info">
		    				<div class="img-testi">
		    					<img src="<?php echo home ?>/assets/images/owais.png">
		    				</div>
		    				<div class="details-testi">
		    					<h3>owais khan sanjrani</h3>
		    					<p>lead of osama</p>
		    				</div>
		    			</div>
		    		</div>
		    		<div class="col-md-6">
		    			<p> 03 / 05 </p>

		    		</div>
		    	</div>
		    </div>
		    <div class="testimonials-box">
		    	<div class="row">
		    		<img src="<?php echo home ?>/assets/images/quote-right.svg" class="quote-right">
		    		<p class="testi-txt">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
		    		<div class="col-md-6">
		    			<div class="person-info">
		    				<div class="img-testi">
		    					<img src="<?php echo home ?>/assets/images/owais.png">
		    				</div>
		    				<div class="details-testi">
		    					<h3>owais khan sanjrani</h3>
		    					<p>lead of osama</p>
		    				</div>
		    			</div>
		    		</div>
		    		<div class="col-md-6">
		    			<p> 04 / 05 </p>

		    		</div>
		    	</div>
		    </div>
		    <div class="testimonials-box">
		    	<div class="row">
		    		<img src="<?php echo home ?>/assets/images/quote-right.svg" class="quote-right">
		    		<p class="testi-txt">Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
		    		<div class="col-md-6">
		    			<div class="person-info">
		    				<div class="img-testi">
		    					<img src="<?php echo home ?>/assets/images/owais.png">
		    				</div>
		    				<div class="details-testi">
		    					<h3>owais khan sanjrani</h3>
		    					<p>lead of osama</p>
		    				</div>
		    			</div>
		    		</div>
		    		<div class="col-md-6">
		    			<p> 04 / 05 </p>

		    		</div>
		    	</div>
		    </div>
			</div>
		</div>
	</div>
</section>
<section class="homepage-sectionone discuss-section" style="background: url('<?php echo home ?>/assets/images/discuss.png');">
	<div class="hero-main-rp container">
		<div class="row">
			<div class="col-lg-10">
				<h2>Ready to discuss your ideas?</h2>
			</div>
			<div class="col-lg-2">
				<div class="learnmr-btn">
					 <a href="#">let’s chat<img src="<?php echo home ?>/assets/images/arrow2.svg"></a>
				</div>
			</div>
		</div>
	</div>
</section>
<!--Start Footer-->
	<?php include('footer.php');?>
<!--End Footer-->