<!--Start Header-->
<?php include('header.php');?>
<!--End Header-->

<section class="inner-banner service-banner inner-service-banner" style="background: url('<?php echo home ?>/assets/images/about-banner.png');">
  <div class="hero-main-rp container">
    <div class="row">
   		<div class="col-md-12">
   			<h2>User Interface (UI) Design Services</h2>
   			<p>Work with the best UI/UX website design company in Dallas. <br/>Reach out to us and we’ll talk you through our UI/UX web designing process!</p>
   		</div>
    </div>
  </div>
</section>
<section class="inner-service-secone">
  <div class="hero-main-rp container">
    <div class="row">
      <div class="col-md-12">
        <h2><img src="<?php echo home ?>assets/images/heading-img.svg"><br/> Why Does UI/UX Design Matter Anyway?</h2>
        <p>An excellent UI/UX design can help retain visitors and attract new ones, especially important for e-comm storefronts. We know how costly a bad experience on a site or an app can be to your brand reputation and relationship with your users. With a flawless user experience (UX) on a user interface (UI) that’s simple to use, you can guarantee a happier consumer.</p>
        <div class="readmore-sec-home">
          <div class="readmr-btn">
            <a href="#">Read More <img src="<?php echo home ?>/assets/images/arrow.png"></a>
          </div>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-md-6">
        <img src="<?php echo home ?>/assets/images/ui-ux-img1.png">
      </div>
      <div class="col-md-6">
        <img src="<?php echo home ?>/assets/images/ui-ux-img.png">
      </div>
    </div>
  </div>
</section>
<section class="inner-service-sectwo">
  <div class="hero-main-rp container">
    <h2><img src="<?php echo home ?>assets/images/heading-img.svg"><br/> So What’s The Difference Between The Two?</h2>
    <div class="row">
      <div class="col-md-6">
        <div class="ui-box">
          <div class="head">
            <h3>01</h3>
          </div>
          <div class="contnt">
            <h4>UI Design</h4>
            <p>All the visual elements of the user’s journey, like swiping through an image carousel or tapping a button on a page, have to look and function seamlessly for a good user experience.</p>
          </div>
        </div>
      </div>
      <div class="col-md-6">
        <div class="ui-box">
          <div class="head">
            <h3>02</h3>
          </div>
          <div class="contnt">
            <h4>UX Design</h4>
            <p>It’s all about the quality of interaction a user has with the interface. The better a user feels in the process of intuitively using your site or app, the more likely you’ll gain a customer for life.</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<section class="inner-service-secthree">
  <div class="hero-main-rp container">
    <h2><img src="<?php echo home ?>assets/images/whiteheadingimg.svg"><br/> Interactive UI/UX Web Design Layouts</h2>
    <p>With so many options and details to consider, how do you know which is best? We’ll talk it through with you to make sure every element keeps your users on your sites and apps and coming back for more!</p>
    <div class="row">
      <div class="col-md-6">
        <div class="web-design-box">
          <div class="head">
            <img src="<?php echo home ?>assets/images/web-design.svg">
          </div>
          <div class="contnt">
            <h3>Web Design</h3>
            <p>If you’re building or refreshing, let us guide you through the whole sitemap and design steps from the structure to graphics and content.</p>
            <div class="btn-box">
              <a href="#">learn more <img src="<?php echo home ?>assets/images/whitearrow.svg"></a>
            </div>
          </div>
        </div>
      </div>
      <div class="col-md-6">
        <div class="web-design-box">
          <div class="head">
            <img src="<?php echo home ?>assets/images/web-app.svg">
          </div>
          <div class="contnt">
            <h3>Web Design</h3>
            <p>If you’re building or refreshing, let us guide you through the whole sitemap and design steps from the structure to graphics and content.</p>
            <div class="btn-box">
              <a href="#">learn more <img src="<?php echo home ?>assets/images/whitearrow.svg"></a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>



<section class="homepage-testimonials">
  <div class="hero-main-rp container">
    <h2>We thrive on <br/>client satisfaction</h2>
    <div class="testimonials">
      <div class="owl-carousel owl-theme owl-testimonials">
        <div class="testimonials-box">
          <div class="row">
            <img src="<?php echo home ?>/assets/images/quote-right.svg" class="quote-right">
            <p class="testi-txt">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
            <div class="col-md-6">
              <div class="person-info">
                <div class="img-testi">
                  <img src="<?php echo home ?>/assets/images/owais.png">
                </div>
                <div class="details-testi">
                  <h3>owais khan sanjrani</h3>
                  <p>lead of osama</p>
                </div>
              </div>
            </div>
            <div class="col-md-6">
              <p> 01 / 05 </p>

            </div>
          </div>
        </div>
        <div class="testimonials-box">
          <div class="row">
            <img src="<?php echo home ?>/assets/images/quote-right.svg" class="quote-right">
            <p class="testi-txt">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
            <div class="col-md-6">
              <div class="person-info">
                <div class="img-testi">
                  <img src="<?php echo home ?>/assets/images/owais.png">
                </div>
                <div class="details-testi">
                  <h3>owais khan sanjrani</h3>
                  <p>lead of osama</p>
                </div>
              </div>
            </div>
            <div class="col-md-6">
              <p> 02 / 05 </p>

            </div>
          </div>
        </div>
        <div class="testimonials-box">
          <div class="row">
            <img src="<?php echo home ?>/assets/images/quote-right.svg" class="quote-right">
            <p class="testi-txt">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
            <div class="col-md-6">
              <div class="person-info">
                <div class="img-testi">
                  <img src="<?php echo home ?>/assets/images/owais.png">
                </div>
                <div class="details-testi">
                  <h3>owais khan sanjrani</h3>
                  <p>lead of osama</p>
                </div>
              </div>
            </div>
            <div class="col-md-6">
              <p> 03 / 05 </p>

            </div>
          </div>
        </div>
        <div class="testimonials-box">
          <div class="row">
            <img src="<?php echo home ?>/assets/images/quote-right.svg" class="quote-right">
            <p class="testi-txt">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
            <div class="col-md-6">
              <div class="person-info">
                <div class="img-testi">
                  <img src="<?php echo home ?>/assets/images/owais.png">
                </div>
                <div class="details-testi">
                  <h3>owais khan sanjrani</h3>
                  <p>lead of osama</p>
                </div>
              </div>
            </div>
            <div class="col-md-6">
              <p> 04 / 05 </p>

            </div>
          </div>
        </div>
        <div class="testimonials-box">
          <div class="row">
            <img src="<?php echo home ?>/assets/images/quote-right.svg" class="quote-right">
            <p class="testi-txt">Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
            <div class="col-md-6">
              <div class="person-info">
                <div class="img-testi">
                  <img src="<?php echo home ?>/assets/images/owais.png">
                </div>
                <div class="details-testi">
                  <h3>owais khan sanjrani</h3>
                  <p>lead of osama</p>
                </div>
              </div>
            </div>
            <div class="col-md-6">
              <p> 04 / 05 </p>

            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<section class="homepage-sectionone discuss-section" style="background: url('<?php echo home ?>/assets/images/discuss.png');">
  <div class="hero-main-rp container">
    <div class="row">
      <div class="col-lg-10">
        <h2>Ready to discuss your ideas?</h2>
      </div>
      <div class="col-lg-2">
        <div class="learnmr-btn">
           <a href="#">let’s chat<img src="<?php echo home ?>/assets/images/arrow2.svg"></a>
        </div>
      </div>
    </div>
  </div>
</section>
<!--Start Footer-->
  <?php include('footer.php');?>
<!--End Footer-->