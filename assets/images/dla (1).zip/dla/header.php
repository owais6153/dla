<?php require('config.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Design Layer Agency</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php include('head.php');?>
  </head>
<body>
<header class="site-header">
    <div class="container">
        <nav class="navbar navbar-default">
 
    <div class="navbar-header">
      <a class="navbar-brand" href="#"><img src="http://localhost/dla/assets/images/logo.svg"></a>
    </div>
    <div class="main-nav">
      <ul class="nav navbar-nav">
        <li class="btn-header"><a href="#">get in touch <img src="http://localhost/dla/assets/images/arrow.png"></a></li>
      </ul>
      <div class="toggle-menu">
        <a href="#">
          <img src="http://localhost/dla/assets/images/toggle-menu.svg">
        </a>
      </div>
    </div>
    
  </nav>
</div>
</header>